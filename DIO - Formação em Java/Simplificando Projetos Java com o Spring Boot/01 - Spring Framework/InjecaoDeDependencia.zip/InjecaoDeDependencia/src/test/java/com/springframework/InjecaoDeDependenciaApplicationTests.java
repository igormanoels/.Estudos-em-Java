package com.springframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InjecaoDeDependenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
