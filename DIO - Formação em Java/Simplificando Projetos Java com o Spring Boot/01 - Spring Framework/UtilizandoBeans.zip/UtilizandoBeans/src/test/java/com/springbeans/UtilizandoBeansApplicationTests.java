package com.springbeans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtilizandoBeansApplicationTests {

	@Test
	void contextLoads() {
	}

}
